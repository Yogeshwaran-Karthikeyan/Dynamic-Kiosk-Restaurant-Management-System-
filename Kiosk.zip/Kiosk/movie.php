<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enhanced Video Player</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            text-align: center;
            margin: 0;
            padding: 20px;
        }
        h1 {
            color: #333;
        }
        video {
            border: 2px solid #333;
            border-radius: 10px;
            margin-top: 20px;
        }
        .controls {
            margin-top: 10px;
        }
        .info {
            margin-top: 15px;
            font-size: 14px;
            color: #555;
        }
    </style>
</head>
<body>
    <h1>Enhanced Video Player</h1>
    <video id="myVideo" width="640" height="360" controls>
        <source src="example.mp4" type="video/mp4">
        <source src="example.webm" type="video/webm">
        <source src="example.ogg" type="video/ogg">
        Your browser does not support the video tag.
    </video>
    <div class="controls">
        <button onclick="playVideo()">Play</button>
        <button onclick="pauseVideo()">Pause</button>
        <button onclick="restartVideo()">Restart</button>
    </div>
    <div class="info">
        <p>Supported formats: MP4, WebM, Ogg.</p>
        <p>Video playing: <span id="status">Stopped</span></p>
    </div>
    <script>
        const video = document.getElementById("myVideo");
        const statusText = document.getElementById("status");

        video.addEventListener("play", () => statusText.innerText = "Playing");
        video.addEventListener("pause", () => statusText.innerText = "Paused");
        video.addEventListener("ended", () => statusText.innerText = "Stopped");

        function playVideo() {
            video.play();
        }

        function pauseVideo() {
            video.pause();
        }

        function restartVideo() {
            video.currentTime = 0;
            video.play();
        }
    </script>
</body>
</html>
