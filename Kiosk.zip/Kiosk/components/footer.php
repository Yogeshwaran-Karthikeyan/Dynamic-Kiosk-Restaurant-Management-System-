<footer class="footer">

   <section class="grid">

      <div class="box">
         <img src="images/email-icon.png" alt="">
         <h3>our email</h3>
         <a href="">yogeshwaran19@gmail.com</a>
         <a href="">praisycathrin@gmail.com</a>
         <a href="">swethats@gmail.com</a>
      </div>

      <div class="box">
         <img src="images/clock-icon.png" alt="">
         <h3>opening hours</h3>
         <p>12 PM TO 9PM</p>
      </div>

      <div class="box">
         <img src="images/map-icon.png" alt="">
         <h3>our address</h3>
         <a href="#">Hotel Annapoorna</a>
      </div>

      <div class="box">
         <img src="images/phone-icon.png" alt="">
         <h3>our number</h3>
         <a href="tel:9876543210">9876543210</a>
         <a href="tel:9876543210">9876543210</a>
      </div>

   </section>

</footer>

<div class="loader">
   <img src="images/loader.gif" alt="">
</div>