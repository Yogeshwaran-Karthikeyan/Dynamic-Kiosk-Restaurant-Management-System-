<?php

include '../components/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if (!isset($admin_id)) {
    header('location:admin_login.php');
    exit();
};

// Add Event
if (isset($_POST['add_event'])) {

    $name = $_POST['name'];
    $name = filter_var($name, FILTER_SANITIZE_STRING);
    $start_date = $_POST['start_date'];
    $start_date = filter_var($start_date, FILTER_SANITIZE_STRING);
    $end_date = $_POST['end_date'];
    $end_date = filter_var($end_date, FILTER_SANITIZE_STRING);
    $discount_rate = $_POST['discount_rate'];
    $discount_rate = filter_var($discount_rate, FILTER_SANITIZE_STRING);

    // Check if event name already exists
    $select_events = $conn->prepare("SELECT * FROM `events` WHERE event_name = ?");
    $select_events->execute([$name]);

    if ($select_events->rowCount() > 0) {
        $message[] = 'Event name already exists!';
    } else {
        // Insert new event
        $insert_event = $conn->prepare("INSERT INTO `events` (event_name, start_date, end_date, discount_rate) VALUES (?, ?, ?, ?)");
        $insert_event->execute([$name, $start_date, $end_date, $discount_rate]);
        $message[] = 'New event added!';
    }
}

// Delete Event
if (isset($_GET['delete'])) {
    // Get and sanitize the event ID
    $delete_id = $_GET['delete'];
    $delete_id = filter_var($delete_id, FILTER_SANITIZE_NUMBER_INT); // Sanitize the delete ID

    // Check if the ID is valid (a positive integer)
    if ($delete_id) {
        // Prepare and execute the delete statement
        $delete_event = $conn->prepare("DELETE FROM `events` WHERE event_id = ?");
        $delete_event->execute([$delete_id]);

        // Redirect to the admin_event.php page after successful deletion
        header('Location: admin_event.php');
        exit();
    } else {
        // If the ID is not valid, show an error message
        echo '<p class="error">Invalid event ID!</p>';
    }
}

// Update Event
if (isset($_POST['update_event'])) {
    // Get and sanitize the data from the form
    $update_id = $_POST['event_id'];
    $name = $_POST['name'];
    $name = filter_var($name, FILTER_SANITIZE_STRING);
    $start_date = $_POST['start_date'];
    $start_date = filter_var($start_date, FILTER_SANITIZE_STRING);
    $end_date = $_POST['end_date'];
    $end_date = filter_var($end_date, FILTER_SANITIZE_STRING);
    $discount_rate = $_POST['discount_rate'];
    $discount_rate = filter_var($discount_rate, FILTER_SANITIZE_STRING);

    // Update the event in the database
    $update_event = $conn->prepare("UPDATE `events` SET event_name = ?, start_date = ?, end_date = ?, discount_rate = ? WHERE event_id = ?");
    $update_event->execute([$name, $start_date, $end_date, $discount_rate, $update_id]);

    // Redirect to the admin_event.php page after successful update
    header('Location: admin_event.php');
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="../css/admin_style.css">
</head>

<body>

<?php include '../components/admin_header.php' ?>

<!-- add events section starts  -->

<section class="add-events">

    <form action="" method="POST">
        <h3>Add Event</h3>
        <input type="text" required placeholder="Enter event name" name="name" maxlength="100" class="box">
        <input type="date" required placeholder="Start date" name="start_date" class="box">
        <input type="date" required placeholder="End date" name="end_date" class="box">
        <input type="number" min="1" max="100" required placeholder="Discount rate (%)" name="discount_rate" class="box">
        <input type="submit" value="Add Event" name="add_event" class="btn">
    </form>

</section>

<!-- add events section ends -->

<!-- show events section starts  -->

<section class="show-events" style="padding-top: 0;">

    <div class="box-container">

        <?php
        // Fetch events from the database
        $show_events = $conn->prepare("SELECT * FROM `events`");
        $show_events->execute();
        if ($show_events->rowCount() > 0) {
            while ($fetch_events = $show_events->fetch(PDO::FETCH_ASSOC)) {
        ?>
                <div class="box">
                    <div class="name"><?= $fetch_events['event_name']; ?></div>
                    <div class="date">Start: <?= $fetch_events['start_date']; ?></div>
                    <div class="date">End: <?= $fetch_events['end_date']; ?></div>
                    <div class="discount">Discount: <?= $fetch_events['discount_rate']; ?>%</div>
                    <div class="flex-btn">
                        <a href="admin_event.php?delete=<?= $fetch_events['event_id']; ?>" class="delete-btn" onclick="return confirm('Delete this event?');">Delete</a>
                        <a href="admin_event.php?edit=<?= $fetch_events['event_id']; ?>" class="edit-btn">Edit</a>
                    </div>
                </div>
        <?php
            }
        } else {
            echo '<p class="empty">No events added yet!</p>';
        }
        ?>

    </div>

</section>

<!-- show events section ends -->

<!-- modify event section starts -->

<?php
// Fetch the event details if 'edit' is set in the URL
if (isset($_GET['edit'])) {
    $edit_id = $_GET['edit'];
    $edit_event = $conn->prepare("SELECT * FROM `events` WHERE event_id = ?");
    $edit_event->execute([$edit_id]);
    $fetch_event = $edit_event->fetch(PDO::FETCH_ASSOC);
?>
    <section class="modify-events">
        <form action="" method="POST">
            <h3>Modify Event</h3>
            <input type="hidden" name="event_id" value="<?= $fetch_event['event_id']; ?>">
            <input type="text" name="name" value="<?= $fetch_event['event_name']; ?>" required class="box">
            <input type="date" name="start_date" value="<?= $fetch_event['start_date']; ?>" required class="box">
            <input type="date" name="end_date" value="<?= $fetch_event['end_date']; ?>" required class="box">
            <input type="number" name="discount_rate" value="<?= $fetch_event['discount_rate']; ?>" required class="box" min="1" max="100">
            <input type="submit" name="update_event" value="Update Event" class="btn">
        </form>
    </section>
<?php
}
?>

<!-- modify event section ends -->

<!-- custom js file link  -->
<script src="../js/admin_script.js"></script>

</body>

</html>
