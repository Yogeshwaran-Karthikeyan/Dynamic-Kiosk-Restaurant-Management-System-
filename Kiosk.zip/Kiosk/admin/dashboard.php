<?php

include '../components/connect.php';

session_start();

$admin_id = $_SESSION['admin_id'];

if (!isset($admin_id)) {
    header('location:admin_login.php');
    exit();
}

// Set timezone
date_default_timezone_set("Asia/Kolkata"); // Adjust for your timezone

// Initialize variables for date range and total earnings
$start_date = isset($_POST['start_date']) ? $_POST['start_date'] : date('Y-m-d');
$end_date = isset($_POST['end_date']) ? $_POST['end_date'] : date('Y-m-d');
$total_earned = 0;

// Fetch total earnings for the selected date range
if (isset($_POST['view_earnings'])) {
    $select_total_earnings = $conn->prepare("SELECT SUM(total_price) AS total_earned FROM `orders` WHERE DATE(placed_on) BETWEEN ? AND ?");
    $select_total_earnings->execute([$start_date, $end_date]);
    $fetch_total_earnings = $select_total_earnings->fetch(PDO::FETCH_ASSOC);
    $total_earned = $fetch_total_earnings['total_earned'] ?? 0;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="../css/admin_style.css">

</head>
<body>

<?php include '../components/admin_header.php' ?>

<!-- admin dashboard section starts  -->

<section class="dashboard">

    <h1 class="heading">Dashboard</h1>

    <div class="box-container">

        <div class="box">
            <h3>Welcome!</h3>
            <p><?= $fetch_profile['name']; ?></p>
            <a href="update_profile.php" class="btn">Update Profile</a>
        </div>

        <!-- Date Range Earnings Section -->
        <div class="box">
        <form action="" method="post" class="date-range-form">
    <label for="start_date"><b>StartDate:</b></label>
    <input type="date" name="start_date" id="start_date" class="large-date-picker" value="<?= $start_date; ?>" required>
    <label for="end_date"><b>EndDate:</b></label>
    <input type="date" name="end_date" id="end_date" class="large-date-picker" value="<?= $end_date; ?>" required>
    <input type="submit" name="view_earnings" value="View Earnings" class="btn">
</form>

            <h3><span>Rs </span><?= number_format($total_earned, 2); ?><span>/-</span></h3>
            <p>Total Earnings (<?= $start_date; ?> to <?= $end_date; ?>)</p>
        </div>

        <div class="box">
            <?php
            $total_pendings = 0;
            $select_pendings = $conn->prepare("SELECT * FROM `orders` WHERE payment_status = ?");
            $select_pendings->execute(['pending']);
            while ($fetch_pendings = $select_pendings->fetch(PDO::FETCH_ASSOC)) {
                $total_pendings += $fetch_pendings['total_price'];
            }
            ?>
            <h3><span>Rs </span><?= $total_pendings; ?><span>/-</span></h3>
            <p>Total Pendings</p>
            <a href="placed_orders.php" class="btn">See Orders</a>
        </div>

        <div class="box">
            <?php
            $total_completes = 0;
            $select_completes = $conn->prepare("SELECT * FROM `orders` WHERE payment_status = ?");
            $select_completes->execute(['completed']);
            while ($fetch_completes = $select_completes->fetch(PDO::FETCH_ASSOC)) {
                $total_completes += $fetch_completes['total_price'];
            }
            ?>
            <h3><span>Rs </span><?= $total_completes; ?><span>/-</span></h3>
            <p>Total Completes</p>
            <a href="placed_orders.php" class="btn">See Orders</a>
        </div>

        <div class="box">
            <?php
            $select_orders = $conn->prepare("SELECT * FROM `orders`");
            $select_orders->execute();
            $numbers_of_orders = $select_orders->rowCount();
            ?>
            <h3><?= $numbers_of_orders; ?></h3>
            <p>Total Orders</p>
            <a href="placed_orders.php" class="btn">See Orders</a>
        </div>

        <div class="box">
            <?php
            $select_products = $conn->prepare("SELECT * FROM `products`");
            $select_products->execute();
            $numbers_of_products = $select_products->rowCount();
            ?>
            <h3><?= $numbers_of_products; ?></h3>
            <p>Products Added</p>
            <a href="products.php" class="btn">See Products</a>
        </div>

        <div class="box">
            <?php
            $select_users = $conn->prepare("SELECT * FROM `users`");
            $select_users->execute();
            $numbers_of_users = $select_users->rowCount();
            ?>
            <h3><?= $numbers_of_users; ?></h3>
            <p>Users Accounts</p>
            <a href="users_accounts.php" class="btn">See Users</a>
        </div>

        <div class="box">
            <?php
            $select_admins = $conn->prepare("SELECT * FROM `admin`");
            $select_admins->execute();
            $numbers_of_admins = $select_admins->rowCount();
            ?>
            <h3><?= $numbers_of_admins; ?></h3>
            <p>Admins</p>
            <a href="admin_accounts.php" class="btn">See Admins</a>
        </div>

        <div class="box">
            <?php
            $select_messages = $conn->prepare("SELECT * FROM `messages`");
            $select_messages->execute();
            $numbers_of_messages = $select_messages->rowCount();
            ?>
            <h3><?= $numbers_of_messages; ?></h3>
            <p>New Messages</p>
            <a href="messages.php" class="btn">See Messages</a>
        </div>

    </div>

</section>

<!-- admin dashboard section ends -->

<!-- custom js file link  -->
<script src="../js/admin_script.js"></script>

</body>
</html>
